/* Copyright 2015 The TensorFlow Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

package tp.sd.dlsd.PDI;

import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import tp.sd.dlsd.PDI.Classifier.Recognition;

public class RecognitionScoreView extends View implements ResultsView {
  private static final float TEXT_SIZE_DIP = 20;
  private List<Recognition> results;
  private final float textSizePx;
  private final Paint fgPaint;
  private final Paint bgPaint;

  public RecognitionScoreView(final Context context, final AttributeSet set) {
    super(context, set);

    textSizePx =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, TEXT_SIZE_DIP, getResources().getDisplayMetrics());
    fgPaint = new Paint();
    fgPaint.setTextSize(textSizePx);

    bgPaint = new Paint();
    bgPaint.setColor(0xcc4285f4);
  }

  @Override
  public void setResults(final List<Recognition> results) {
    this.results = results;
    postInvalidate();
  }

  @Override
  public void onDraw(final Canvas canvas) {
    DecimalFormat decimalFormat = new DecimalFormat("#.###");
    final int x = 10;
    int y = (int) (fgPaint.getTextSize() * 1.5f);
    String name = "";;
    String name2 = "";
    Float confidence = 0.0f;
    String link = "";
    String disease = "";
    String actions = "";

    canvas.drawPaint(bgPaint);

    List <String> list = new ArrayList<String>();

    list = readFromAssets("PlantRef.txt", this.getContext());

    if (results != null) {
      for (final Recognition recog : results) {
        float confidenceScore = Float.valueOf(decimalFormat.format(recog.getConfidence()));
        canvas.drawText(recog.getTitle() + ": " + confidenceScore, x, y, fgPaint);
        y += fgPaint.getTextSize() * 1.5f;
      }

      for(int i =0 ; i < 3 - results.size(); i++) {
        canvas.drawText("", x, y, fgPaint);
        y += fgPaint.getTextSize() * 1.5f;
      }

      for (String plant : list) {
        name = plant.split(";")[0];
        link = plant.split(";")[1];

        name2 = results.get(0).getTitle();
        confidence = Float.valueOf(results.get(0).getConfidence());
        if (name.equals(name2)) {
          //canvas.drawText(name2 + ": " + confidence, x, y, fgPaint);
          //y += fgPaint.getTextSize() * 1.5f;
          canvas.drawText("", x, y, fgPaint);
          y += fgPaint.getTextSize() * 1.5f;
          canvas.drawText("For more information:", x, y, fgPaint);
          y += fgPaint.getTextSize() * 1.5f;
          canvas.drawText(link, x, y, fgPaint);
        }
      }
    }
  }

  public List<String> readFromAssets(String fileName, Context context) {
    List<String> returnString = new ArrayList<String>();
    InputStream fIn = null;
    InputStreamReader isr = null;
    BufferedReader input = null;
    try {
      fIn = context.getResources().getAssets().open(fileName, Context.MODE_PRIVATE);
      isr = new InputStreamReader(fIn);
      input = new BufferedReader(isr);
      String line = "";
      while ((line = input.readLine()) != null) {
        returnString.add(line);
      }
    } catch (Exception e) {
      e.getMessage();
    } finally {
      try {
        if (isr != null)
          isr.close();
        if (fIn != null)
          fIn.close();
        if (input != null)
          input.close();
      } catch (Exception e2) {
        e2.getMessage();
      }
    }
    return returnString;
  }
}
